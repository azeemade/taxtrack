<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionRefund extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    public function subscriptionHistory()
    {
        return $this->belongsTo(SubscriptionHistory::class, 'subscription_history_id');
    }

    public function subscriptionPlan()
    {
        return $this->belongsTo(SubscriptionPlan::class, 'subscription_plan_id');
    }
}
